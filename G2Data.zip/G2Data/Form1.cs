﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G2Data
{
    public partial class Form1 : Form
    {
        MS_PARAM moves;
        MS_Entries currSelected;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            moves = new MS_PARAM();
            currSelected = null;
            for (ushort i = 0; i < moves.numEntries(); i++)
            {
                string cmboString = new string(moves.getEntry(i).name);
                cmboString = cmboString.Trim();
                MS_cmbo.Items.Add(cmboString);
            }
        }

        private void MS_cmbo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(currSelected != null)
            {
                //currSelected.icon = Convert.ToByte(txbIcon.Text);
                if(!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (txbName.Text.Length > 18)
                    MessageBox.Show("Move name is too long",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);
                else
                {
                    for (int i = 0; i < txbName.Text.Length; i++)
                        currSelected.name[18 - i] = txbName.Text[txbName.Text.Length - i - 1];

                    for (int i = 0; i < 18 - txbName.Text.Length; i++)
                        currSelected.name[i] = ' ';
                 }

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);

                if (!byte.TryParse(txbIcon.Text, out currSelected.icon))
                    MessageBox.Show("Invalid icon value inputted",
                                    "Invalid data",
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Error);
            }

            currSelected = moves.getEntry(Convert.ToUInt16(MS_cmbo.SelectedIndex));
            string tempStr;
            txbIcon.Text = currSelected.icon.ToString();

            tempStr = new string(currSelected.name);
            txbName.Text = tempStr;

            txbCost.Text = currSelected.cost.ToString();
            txbTE.Text = currSelected.targetEffect.ToString();
            txbTT.Text = currSelected.targetType.ToString();
            txbStrength.Text = currSelected.strength.ToString();
            txbPower.Text = currSelected.power.ToString();
            txbRange.Text = currSelected.range.ToString();
            txbCastTime1.Text = currSelected.castTime1.ToString();
            txbCastTime5.Text = currSelected.castTime5.ToString();
            txbRecovery.Text = currSelected.recoveryTime.ToString();
            txbAnimation.Text = currSelected.animation.ToString();
            txbIPD.Text = currSelected.IPDamage.ToString();
            txbIPC.Text = currSelected.IPCancel.ToString();
            txbKnockback.Text = currSelected.knockback.ToString();
            txbElement.Text = currSelected.element.ToString();
            txbElementMod.Text = currSelected.elementStrength.ToString();
            txbAilments.Text = currSelected.ailments.ToString();
            txbAilmentChance.Text = currSelected.ailmentChance.ToString();
            txbStrMod.Text = currSelected.strMod.ToString();
            txbDefMod.Text = currSelected.defMod.ToString();
            txbActMod.Text = currSelected.actMod.ToString();
            txbMovMod.Text = currSelected.movMod.ToString();
            txbSpecial.Text = currSelected.specialEffect.ToString();
            txbCost1.Text = currSelected.cost1.ToString();
            txbCost2.Text = currSelected.cost2.ToString();
            txbCost3.Text = currSelected.cost3.ToString();
            txbCost4.Text = currSelected.cost4.ToString();
            txbCost5.Text = currSelected.cost5.ToString();
            txbMultiplier.Text = currSelected.powMult.ToString();

            tempStr = new string(currSelected.description);
            txbDescription.Text = tempStr;
        }
    }
}

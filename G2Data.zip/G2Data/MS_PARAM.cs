﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace G2Data
{
    class MS_Entries   //108 bytes total
    {
        public byte offset;
        public byte icon;
        public char[] name;
        public ushort cost;
        public byte targetEffect;
        public byte targetType;
        public ushort strength;
        public ushort power;
        public ushort range;
        public ushort castTime1;
        public ushort castTime5;
        public ushort recoveryTime;
        public ushort animation;
        public byte[] unknown;
        public short IPDamage;
        public short IPCancel;
        public short knockback;
        public byte element;
        public byte elementStrength;
        public byte ailments;
        public byte ailmentChance;
        public sbyte strMod;
        public sbyte defMod;
        public sbyte actMod;
        public sbyte movMod;
        public ushort specialEffect;
        public ushort cost1;
        public ushort cost2;
        public ushort cost3;
        public ushort cost4;
        public ushort cost5;
        public ushort powMult;
        public char[] description;

        public MS_Entries()
        {
            name = new char[18];
            unknown = new byte[2];
            description = new char[40];
        }
    }

    class MS_PARAM
    {
        MS_Entries[] moveList;

        public MS_PARAM()
        {
            moveList = new MS_Entries[128];

            for (int i = 0; i < 128; i++)
                moveList[i] = new MS_Entries();

            if (!File.Exists(@"data\\afs\\xls_data\\MS_PARAM.BIN"))
            {
                MessageBox.Show("Failed to find MS_PARAM.BIN at " +
                                @"data\\afs\\xls_data",
                                "File does not exist",
                                MessageBoxButtons.OKCancel,
                                MessageBoxIcon.Error);
                Application.Exit();
            }

            byte[] fileBytes = File.ReadAllBytes(@"data\\afs\\xls_data\\MS_PARAM.BIN");

            for(byte i = 0; i < 128; i++)
            {
                moveList[i].offset = i;
                moveList[i].icon   = fileBytes[1 + (108 * i)];

                for(int j = 0; j < 18; j++)
                    moveList[i].name[j] = Convert.ToChar(fileBytes[2 + (108 * i) + j]);

                moveList[i].cost  = Convert.ToUInt16((fileBytes[21 + (108 * i)] << 8) + fileBytes[20 + (108 * i)]);
                moveList[i].targetEffect = fileBytes[22 + (108 * i)];
                moveList[i].targetType = fileBytes[23 + (108 * i)];
                moveList[i].strength = Convert.ToUInt16((fileBytes[25 + (108 * i)] << 8) + fileBytes[24 + (108 * i)]);
                moveList[i].power = Convert.ToUInt16((fileBytes[27 + (108 * i)] << 8) + fileBytes[26 + (108 * i)]);
                moveList[i].range = Convert.ToUInt16((fileBytes[29 + (108 * i)] << 8) + fileBytes[28 + (108 * i)]);
                moveList[i].castTime1 = Convert.ToUInt16((fileBytes[31 + (108 * i)] << 8) + fileBytes[30 + (108 * i)]);
                moveList[i].castTime5 = Convert.ToUInt16((fileBytes[33 + (108 * i)] << 8) + fileBytes[32 + (108 * i)]);
                moveList[i].recoveryTime = Convert.ToUInt16((fileBytes[35 + (108 * i)] << 8) + fileBytes[34 + (108 * i)]);
                moveList[i].animation = Convert.ToUInt16((fileBytes[37 + (108 * i)] << 8) + fileBytes[36 + (108 * i)]);

                for (int j = 0; j < 2; j++)
                    moveList[i].unknown[j] = fileBytes[38 + (108 * i) + j];

                moveList[i].IPDamage = Convert.ToInt16((fileBytes[41 + (108 * i)] << 8) + fileBytes[40 + (108 * i)]);
                moveList[i].IPCancel = Convert.ToInt16((fileBytes[43 + (108 * i)] << 8) + fileBytes[42 + (108 * i)]);
                moveList[i].knockback = Convert.ToInt16((fileBytes[45 + (108 * i)] << 8) + fileBytes[44 + (108 * i)]);
                moveList[i].element = fileBytes[46 + (108 * i)];
                moveList[i].elementStrength = fileBytes[47 + (108 * i)];
                moveList[i].ailments = fileBytes[48 + (108 * i)];
                moveList[i].ailmentChance = fileBytes[49 + (108 * i)];
                moveList[i].strMod = unchecked((sbyte)fileBytes[50 + (108 * i)]);
                moveList[i].defMod = unchecked((sbyte)fileBytes[51 + (108 * i)]);
                moveList[i].actMod = unchecked((sbyte)fileBytes[52 + (108 * i)]);
                moveList[i].movMod = unchecked((sbyte)fileBytes[53 + (108 * i)]);

                moveList[i].specialEffect = Convert.ToUInt16((fileBytes[55 + (108 * i)] << 8) + fileBytes[54 + (108 * i)]);

                moveList[i].cost1 = Convert.ToUInt16((fileBytes[57 + (108 * i)] << 8) + fileBytes[56 + (108 * i)]);
                moveList[i].cost2 = Convert.ToUInt16((fileBytes[59 + (108 * i)] << 8) + fileBytes[58 + (108 * i)]);
                moveList[i].cost3 = Convert.ToUInt16((fileBytes[61 + (108 * i)] << 8) + fileBytes[60 + (108 * i)]);
                moveList[i].cost4 = Convert.ToUInt16((fileBytes[63 + (108 * i)] << 8) + fileBytes[62 + (108 * i)]);
                moveList[i].cost5 = Convert.ToUInt16((fileBytes[65 + (108 * i)] << 8) + fileBytes[64 + (108 * i)]);

                moveList[i].powMult = Convert.ToUInt16((fileBytes[67 + (108 * i)] << 8) + fileBytes[66 + (108 * i)]);

                for (int j = 0; j < 40; j++)
                    moveList[i].description[j] = Convert.ToChar(fileBytes[68 + (108 * i) + j]);
            }
        }

        public MS_Entries getEntry(ushort index)
        {
            return moveList[index];
        }

        public ushort numEntries()
        {
            return 128;
        }
    }
}

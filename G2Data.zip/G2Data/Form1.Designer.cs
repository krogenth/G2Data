﻿namespace G2Data
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabCtrl = new System.Windows.Forms.TabControl();
            this.Moves = new System.Windows.Forms.TabPage();
            this.txbMultiplier = new System.Windows.Forms.TextBox();
            this.txbDescription = new System.Windows.Forms.TextBox();
            this.txbCost1 = new System.Windows.Forms.TextBox();
            this.txbCost2 = new System.Windows.Forms.TextBox();
            this.txbMovMod = new System.Windows.Forms.TextBox();
            this.txbActMod = new System.Windows.Forms.TextBox();
            this.txbDefMod = new System.Windows.Forms.TextBox();
            this.txbStrMod = new System.Windows.Forms.TextBox();
            this.txbAilmentChance = new System.Windows.Forms.TextBox();
            this.txbAilments = new System.Windows.Forms.TextBox();
            this.txbCost3 = new System.Windows.Forms.TextBox();
            this.txbCost4 = new System.Windows.Forms.TextBox();
            this.txbElementMod = new System.Windows.Forms.TextBox();
            this.txbElement = new System.Windows.Forms.TextBox();
            this.txbKnockback = new System.Windows.Forms.TextBox();
            this.txbIPC = new System.Windows.Forms.TextBox();
            this.txbIPD = new System.Windows.Forms.TextBox();
            this.txbAnimation = new System.Windows.Forms.TextBox();
            this.txbRecovery = new System.Windows.Forms.TextBox();
            this.txbCastTime5 = new System.Windows.Forms.TextBox();
            this.txbCastTime1 = new System.Windows.Forms.TextBox();
            this.txbRange = new System.Windows.Forms.TextBox();
            this.txbPower = new System.Windows.Forms.TextBox();
            this.txbStrength = new System.Windows.Forms.TextBox();
            this.txbTT = new System.Windows.Forms.TextBox();
            this.txbTE = new System.Windows.Forms.TextBox();
            this.txbCost = new System.Windows.Forms.TextBox();
            this.txbName = new System.Windows.Forms.TextBox();
            this.txbIcon = new System.Windows.Forms.TextBox();
            this.txbCost5 = new System.Windows.Forms.TextBox();
            this.lblMovMod = new System.Windows.Forms.Label();
            this.lblSpecial = new System.Windows.Forms.Label();
            this.lblCost1 = new System.Windows.Forms.Label();
            this.lblCost2 = new System.Windows.Forms.Label();
            this.lblCost3 = new System.Windows.Forms.Label();
            this.lblCost4 = new System.Windows.Forms.Label();
            this.lblCost5 = new System.Windows.Forms.Label();
            this.lblMultiplier = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblIPC = new System.Windows.Forms.Label();
            this.lblKnockback = new System.Windows.Forms.Label();
            this.lblElement = new System.Windows.Forms.Label();
            this.lblElementMod = new System.Windows.Forms.Label();
            this.lblAilment = new System.Windows.Forms.Label();
            this.lblAilmentChance = new System.Windows.Forms.Label();
            this.lblStrMod = new System.Windows.Forms.Label();
            this.lblDefMod = new System.Windows.Forms.Label();
            this.lblActMod = new System.Windows.Forms.Label();
            this.lblCost = new System.Windows.Forms.Label();
            this.lblTE = new System.Windows.Forms.Label();
            this.lblTT = new System.Windows.Forms.Label();
            this.lblStrength = new System.Windows.Forms.Label();
            this.lblPower = new System.Windows.Forms.Label();
            this.lblRange = new System.Windows.Forms.Label();
            this.lblCharge1 = new System.Windows.Forms.Label();
            this.lblCharge5 = new System.Windows.Forms.Label();
            this.lblRecovery = new System.Windows.Forms.Label();
            this.lblAnimation = new System.Windows.Forms.Label();
            this.lblIPD = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblIcon = new System.Windows.Forms.Label();
            this.txbSpecial = new System.Windows.Forms.TextBox();
            this.MS_cmbo = new System.Windows.Forms.ComboBox();
            this.Skills = new System.Windows.Forms.TabPage();
            this.Levels = new System.Windows.Forms.TabPage();
            this.tabCtrl.SuspendLayout();
            this.Moves.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabCtrl
            // 
            this.tabCtrl.Controls.Add(this.Moves);
            this.tabCtrl.Controls.Add(this.Skills);
            this.tabCtrl.Controls.Add(this.Levels);
            this.tabCtrl.Location = new System.Drawing.Point(15, 16);
            this.tabCtrl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabCtrl.Name = "tabCtrl";
            this.tabCtrl.SelectedIndex = 0;
            this.tabCtrl.Size = new System.Drawing.Size(2164, 1374);
            this.tabCtrl.TabIndex = 0;
            // 
            // Moves
            // 
            this.Moves.Controls.Add(this.txbMultiplier);
            this.Moves.Controls.Add(this.txbDescription);
            this.Moves.Controls.Add(this.txbCost1);
            this.Moves.Controls.Add(this.txbCost2);
            this.Moves.Controls.Add(this.txbMovMod);
            this.Moves.Controls.Add(this.txbActMod);
            this.Moves.Controls.Add(this.txbDefMod);
            this.Moves.Controls.Add(this.txbStrMod);
            this.Moves.Controls.Add(this.txbAilmentChance);
            this.Moves.Controls.Add(this.txbAilments);
            this.Moves.Controls.Add(this.txbCost3);
            this.Moves.Controls.Add(this.txbCost4);
            this.Moves.Controls.Add(this.txbElementMod);
            this.Moves.Controls.Add(this.txbElement);
            this.Moves.Controls.Add(this.txbKnockback);
            this.Moves.Controls.Add(this.txbIPC);
            this.Moves.Controls.Add(this.txbIPD);
            this.Moves.Controls.Add(this.txbAnimation);
            this.Moves.Controls.Add(this.txbRecovery);
            this.Moves.Controls.Add(this.txbCastTime5);
            this.Moves.Controls.Add(this.txbCastTime1);
            this.Moves.Controls.Add(this.txbRange);
            this.Moves.Controls.Add(this.txbPower);
            this.Moves.Controls.Add(this.txbStrength);
            this.Moves.Controls.Add(this.txbTT);
            this.Moves.Controls.Add(this.txbTE);
            this.Moves.Controls.Add(this.txbCost);
            this.Moves.Controls.Add(this.txbName);
            this.Moves.Controls.Add(this.txbIcon);
            this.Moves.Controls.Add(this.txbCost5);
            this.Moves.Controls.Add(this.lblMovMod);
            this.Moves.Controls.Add(this.lblSpecial);
            this.Moves.Controls.Add(this.lblCost1);
            this.Moves.Controls.Add(this.lblCost2);
            this.Moves.Controls.Add(this.lblCost3);
            this.Moves.Controls.Add(this.lblCost4);
            this.Moves.Controls.Add(this.lblCost5);
            this.Moves.Controls.Add(this.lblMultiplier);
            this.Moves.Controls.Add(this.lblDescription);
            this.Moves.Controls.Add(this.lblIPC);
            this.Moves.Controls.Add(this.lblKnockback);
            this.Moves.Controls.Add(this.lblElement);
            this.Moves.Controls.Add(this.lblElementMod);
            this.Moves.Controls.Add(this.lblAilment);
            this.Moves.Controls.Add(this.lblAilmentChance);
            this.Moves.Controls.Add(this.lblStrMod);
            this.Moves.Controls.Add(this.lblDefMod);
            this.Moves.Controls.Add(this.lblActMod);
            this.Moves.Controls.Add(this.lblCost);
            this.Moves.Controls.Add(this.lblTE);
            this.Moves.Controls.Add(this.lblTT);
            this.Moves.Controls.Add(this.lblStrength);
            this.Moves.Controls.Add(this.lblPower);
            this.Moves.Controls.Add(this.lblRange);
            this.Moves.Controls.Add(this.lblCharge1);
            this.Moves.Controls.Add(this.lblCharge5);
            this.Moves.Controls.Add(this.lblRecovery);
            this.Moves.Controls.Add(this.lblAnimation);
            this.Moves.Controls.Add(this.lblIPD);
            this.Moves.Controls.Add(this.lblName);
            this.Moves.Controls.Add(this.lblIcon);
            this.Moves.Controls.Add(this.txbSpecial);
            this.Moves.Controls.Add(this.MS_cmbo);
            this.Moves.Location = new System.Drawing.Point(4, 25);
            this.Moves.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Moves.Name = "Moves";
            this.Moves.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Moves.Size = new System.Drawing.Size(2156, 1345);
            this.Moves.TabIndex = 0;
            this.Moves.Text = "Moves";
            this.Moves.UseVisualStyleBackColor = true;
            // 
            // txbMultiplier
            // 
            this.txbMultiplier.Location = new System.Drawing.Point(273, 876);
            this.txbMultiplier.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbMultiplier.Name = "txbMultiplier";
            this.txbMultiplier.Size = new System.Drawing.Size(116, 22);
            this.txbMultiplier.TabIndex = 65;
            // 
            // txbDescription
            // 
            this.txbDescription.Location = new System.Drawing.Point(273, 906);
            this.txbDescription.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbDescription.Name = "txbDescription";
            this.txbDescription.Size = new System.Drawing.Size(242, 22);
            this.txbDescription.TabIndex = 64;
            // 
            // txbCost1
            // 
            this.txbCost1.Location = new System.Drawing.Point(273, 726);
            this.txbCost1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbCost1.Name = "txbCost1";
            this.txbCost1.Size = new System.Drawing.Size(116, 22);
            this.txbCost1.TabIndex = 63;
            // 
            // txbCost2
            // 
            this.txbCost2.Location = new System.Drawing.Point(273, 756);
            this.txbCost2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbCost2.Name = "txbCost2";
            this.txbCost2.Size = new System.Drawing.Size(116, 22);
            this.txbCost2.TabIndex = 62;
            // 
            // txbMovMod
            // 
            this.txbMovMod.Location = new System.Drawing.Point(273, 666);
            this.txbMovMod.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbMovMod.Name = "txbMovMod";
            this.txbMovMod.Size = new System.Drawing.Size(116, 22);
            this.txbMovMod.TabIndex = 61;
            // 
            // txbActMod
            // 
            this.txbActMod.Location = new System.Drawing.Point(273, 636);
            this.txbActMod.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbActMod.Name = "txbActMod";
            this.txbActMod.Size = new System.Drawing.Size(116, 22);
            this.txbActMod.TabIndex = 60;
            // 
            // txbDefMod
            // 
            this.txbDefMod.Location = new System.Drawing.Point(273, 606);
            this.txbDefMod.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbDefMod.Name = "txbDefMod";
            this.txbDefMod.Size = new System.Drawing.Size(116, 22);
            this.txbDefMod.TabIndex = 59;
            // 
            // txbStrMod
            // 
            this.txbStrMod.Location = new System.Drawing.Point(273, 576);
            this.txbStrMod.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbStrMod.Name = "txbStrMod";
            this.txbStrMod.Size = new System.Drawing.Size(116, 22);
            this.txbStrMod.TabIndex = 58;
            // 
            // txbAilmentChance
            // 
            this.txbAilmentChance.Location = new System.Drawing.Point(273, 546);
            this.txbAilmentChance.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbAilmentChance.Name = "txbAilmentChance";
            this.txbAilmentChance.Size = new System.Drawing.Size(116, 22);
            this.txbAilmentChance.TabIndex = 57;
            // 
            // txbAilments
            // 
            this.txbAilments.Location = new System.Drawing.Point(273, 516);
            this.txbAilments.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbAilments.Name = "txbAilments";
            this.txbAilments.Size = new System.Drawing.Size(116, 22);
            this.txbAilments.TabIndex = 56;
            // 
            // txbCost3
            // 
            this.txbCost3.Location = new System.Drawing.Point(273, 786);
            this.txbCost3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbCost3.Name = "txbCost3";
            this.txbCost3.Size = new System.Drawing.Size(116, 22);
            this.txbCost3.TabIndex = 55;
            // 
            // txbCost4
            // 
            this.txbCost4.Location = new System.Drawing.Point(273, 816);
            this.txbCost4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbCost4.Name = "txbCost4";
            this.txbCost4.Size = new System.Drawing.Size(116, 22);
            this.txbCost4.TabIndex = 54;
            // 
            // txbElementMod
            // 
            this.txbElementMod.Location = new System.Drawing.Point(273, 486);
            this.txbElementMod.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbElementMod.Name = "txbElementMod";
            this.txbElementMod.Size = new System.Drawing.Size(116, 22);
            this.txbElementMod.TabIndex = 53;
            // 
            // txbElement
            // 
            this.txbElement.Location = new System.Drawing.Point(273, 456);
            this.txbElement.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbElement.Name = "txbElement";
            this.txbElement.Size = new System.Drawing.Size(116, 22);
            this.txbElement.TabIndex = 52;
            // 
            // txbKnockback
            // 
            this.txbKnockback.Location = new System.Drawing.Point(273, 426);
            this.txbKnockback.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbKnockback.Name = "txbKnockback";
            this.txbKnockback.Size = new System.Drawing.Size(116, 22);
            this.txbKnockback.TabIndex = 51;
            // 
            // txbIPC
            // 
            this.txbIPC.Location = new System.Drawing.Point(273, 396);
            this.txbIPC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbIPC.Name = "txbIPC";
            this.txbIPC.Size = new System.Drawing.Size(116, 22);
            this.txbIPC.TabIndex = 50;
            // 
            // txbIPD
            // 
            this.txbIPD.Location = new System.Drawing.Point(273, 366);
            this.txbIPD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbIPD.Name = "txbIPD";
            this.txbIPD.Size = new System.Drawing.Size(116, 22);
            this.txbIPD.TabIndex = 49;
            // 
            // txbAnimation
            // 
            this.txbAnimation.Location = new System.Drawing.Point(273, 336);
            this.txbAnimation.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbAnimation.Name = "txbAnimation";
            this.txbAnimation.Size = new System.Drawing.Size(116, 22);
            this.txbAnimation.TabIndex = 48;
            // 
            // txbRecovery
            // 
            this.txbRecovery.Location = new System.Drawing.Point(273, 306);
            this.txbRecovery.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbRecovery.Name = "txbRecovery";
            this.txbRecovery.Size = new System.Drawing.Size(116, 22);
            this.txbRecovery.TabIndex = 47;
            // 
            // txbCastTime5
            // 
            this.txbCastTime5.Location = new System.Drawing.Point(273, 276);
            this.txbCastTime5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbCastTime5.Name = "txbCastTime5";
            this.txbCastTime5.Size = new System.Drawing.Size(116, 22);
            this.txbCastTime5.TabIndex = 46;
            // 
            // txbCastTime1
            // 
            this.txbCastTime1.Location = new System.Drawing.Point(273, 246);
            this.txbCastTime1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbCastTime1.Name = "txbCastTime1";
            this.txbCastTime1.Size = new System.Drawing.Size(116, 22);
            this.txbCastTime1.TabIndex = 45;
            // 
            // txbRange
            // 
            this.txbRange.Location = new System.Drawing.Point(273, 216);
            this.txbRange.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbRange.Name = "txbRange";
            this.txbRange.Size = new System.Drawing.Size(116, 22);
            this.txbRange.TabIndex = 44;
            // 
            // txbPower
            // 
            this.txbPower.Location = new System.Drawing.Point(273, 186);
            this.txbPower.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbPower.Name = "txbPower";
            this.txbPower.Size = new System.Drawing.Size(116, 22);
            this.txbPower.TabIndex = 43;
            // 
            // txbStrength
            // 
            this.txbStrength.Location = new System.Drawing.Point(273, 156);
            this.txbStrength.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbStrength.Name = "txbStrength";
            this.txbStrength.Size = new System.Drawing.Size(116, 22);
            this.txbStrength.TabIndex = 42;
            // 
            // txbTT
            // 
            this.txbTT.Location = new System.Drawing.Point(273, 126);
            this.txbTT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbTT.Name = "txbTT";
            this.txbTT.Size = new System.Drawing.Size(116, 22);
            this.txbTT.TabIndex = 41;
            // 
            // txbTE
            // 
            this.txbTE.Location = new System.Drawing.Point(273, 96);
            this.txbTE.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbTE.Name = "txbTE";
            this.txbTE.Size = new System.Drawing.Size(116, 22);
            this.txbTE.TabIndex = 40;
            // 
            // txbCost
            // 
            this.txbCost.Location = new System.Drawing.Point(273, 66);
            this.txbCost.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbCost.Name = "txbCost";
            this.txbCost.Size = new System.Drawing.Size(116, 22);
            this.txbCost.TabIndex = 39;
            // 
            // txbName
            // 
            this.txbName.Location = new System.Drawing.Point(273, 36);
            this.txbName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbName.Name = "txbName";
            this.txbName.Size = new System.Drawing.Size(116, 22);
            this.txbName.TabIndex = 38;
            // 
            // txbIcon
            // 
            this.txbIcon.Location = new System.Drawing.Point(273, 6);
            this.txbIcon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbIcon.Name = "txbIcon";
            this.txbIcon.Size = new System.Drawing.Size(116, 22);
            this.txbIcon.TabIndex = 37;
            // 
            // txbCost5
            // 
            this.txbCost5.Location = new System.Drawing.Point(273, 846);
            this.txbCost5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbCost5.Name = "txbCost5";
            this.txbCost5.Size = new System.Drawing.Size(116, 22);
            this.txbCost5.TabIndex = 36;
            // 
            // lblMovMod
            // 
            this.lblMovMod.AutoSize = true;
            this.lblMovMod.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMovMod.Location = new System.Drawing.Point(149, 672);
            this.lblMovMod.Name = "lblMovMod";
            this.lblMovMod.Size = new System.Drawing.Size(87, 16);
            this.lblMovMod.TabIndex = 34;
            this.lblMovMod.Text = "MOV Modifier";
            // 
            // lblSpecial
            // 
            this.lblSpecial.AutoSize = true;
            this.lblSpecial.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpecial.Location = new System.Drawing.Point(149, 702);
            this.lblSpecial.Name = "lblSpecial";
            this.lblSpecial.Size = new System.Drawing.Size(95, 16);
            this.lblSpecial.TabIndex = 33;
            this.lblSpecial.Text = "Special Effects";
            // 
            // lblCost1
            // 
            this.lblCost1.AutoSize = true;
            this.lblCost1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCost1.Location = new System.Drawing.Point(149, 732);
            this.lblCost1.Name = "lblCost1";
            this.lblCost1.Size = new System.Drawing.Size(79, 16);
            this.lblCost1.TabIndex = 32;
            this.lblCost1.Text = "Level 1 Cost";
            // 
            // lblCost2
            // 
            this.lblCost2.AutoSize = true;
            this.lblCost2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCost2.Location = new System.Drawing.Point(149, 762);
            this.lblCost2.Name = "lblCost2";
            this.lblCost2.Size = new System.Drawing.Size(79, 16);
            this.lblCost2.TabIndex = 31;
            this.lblCost2.Text = "Level 2 Cost";
            // 
            // lblCost3
            // 
            this.lblCost3.AutoSize = true;
            this.lblCost3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCost3.Location = new System.Drawing.Point(149, 792);
            this.lblCost3.Name = "lblCost3";
            this.lblCost3.Size = new System.Drawing.Size(79, 16);
            this.lblCost3.TabIndex = 30;
            this.lblCost3.Text = "Level 3 Cost";
            // 
            // lblCost4
            // 
            this.lblCost4.AutoSize = true;
            this.lblCost4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCost4.Location = new System.Drawing.Point(149, 822);
            this.lblCost4.Name = "lblCost4";
            this.lblCost4.Size = new System.Drawing.Size(79, 16);
            this.lblCost4.TabIndex = 29;
            this.lblCost4.Text = "Level 4 Cost";
            // 
            // lblCost5
            // 
            this.lblCost5.AutoSize = true;
            this.lblCost5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCost5.Location = new System.Drawing.Point(149, 852);
            this.lblCost5.Name = "lblCost5";
            this.lblCost5.Size = new System.Drawing.Size(79, 16);
            this.lblCost5.TabIndex = 28;
            this.lblCost5.Text = "Level 5 Cost";
            // 
            // lblMultiplier
            // 
            this.lblMultiplier.AutoSize = true;
            this.lblMultiplier.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMultiplier.Location = new System.Drawing.Point(149, 882);
            this.lblMultiplier.Name = "lblMultiplier";
            this.lblMultiplier.Size = new System.Drawing.Size(100, 16);
            this.lblMultiplier.TabIndex = 27;
            this.lblMultiplier.Text = "Power Multiplier";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescription.Location = new System.Drawing.Point(149, 912);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(73, 16);
            this.lblDescription.TabIndex = 26;
            this.lblDescription.Text = "Description";
            // 
            // lblIPC
            // 
            this.lblIPC.AutoSize = true;
            this.lblIPC.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIPC.Location = new System.Drawing.Point(149, 402);
            this.lblIPC.Name = "lblIPC";
            this.lblIPC.Size = new System.Drawing.Size(116, 16);
            this.lblIPC.TabIndex = 24;
            this.lblIPC.Text = "IP Cancel Damage";
            // 
            // lblKnockback
            // 
            this.lblKnockback.AutoSize = true;
            this.lblKnockback.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKnockback.Location = new System.Drawing.Point(149, 432);
            this.lblKnockback.Name = "lblKnockback";
            this.lblKnockback.Size = new System.Drawing.Size(73, 16);
            this.lblKnockback.TabIndex = 23;
            this.lblKnockback.Text = "Knockback";
            // 
            // lblElement
            // 
            this.lblElement.AutoSize = true;
            this.lblElement.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblElement.Location = new System.Drawing.Point(149, 462);
            this.lblElement.Name = "lblElement";
            this.lblElement.Size = new System.Drawing.Size(56, 16);
            this.lblElement.TabIndex = 22;
            this.lblElement.Text = "Element";
            // 
            // lblElementMod
            // 
            this.lblElementMod.AutoSize = true;
            this.lblElementMod.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblElementMod.Location = new System.Drawing.Point(149, 492);
            this.lblElementMod.Name = "lblElementMod";
            this.lblElementMod.Size = new System.Drawing.Size(109, 16);
            this.lblElementMod.TabIndex = 21;
            this.lblElementMod.Text = "Element Strength";
            // 
            // lblAilment
            // 
            this.lblAilment.AutoSize = true;
            this.lblAilment.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAilment.Location = new System.Drawing.Point(149, 522);
            this.lblAilment.Name = "lblAilment";
            this.lblAilment.Size = new System.Drawing.Size(59, 16);
            this.lblAilment.TabIndex = 20;
            this.lblAilment.Text = "Ailments";
            // 
            // lblAilmentChance
            // 
            this.lblAilmentChance.AutoSize = true;
            this.lblAilmentChance.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAilmentChance.Location = new System.Drawing.Point(149, 552);
            this.lblAilmentChance.Name = "lblAilmentChance";
            this.lblAilmentChance.Size = new System.Drawing.Size(100, 16);
            this.lblAilmentChance.TabIndex = 19;
            this.lblAilmentChance.Text = "Ailment Chance";
            // 
            // lblStrMod
            // 
            this.lblStrMod.AutoSize = true;
            this.lblStrMod.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStrMod.Location = new System.Drawing.Point(149, 582);
            this.lblStrMod.Name = "lblStrMod";
            this.lblStrMod.Size = new System.Drawing.Size(82, 16);
            this.lblStrMod.TabIndex = 18;
            this.lblStrMod.Text = "STR Modifier";
            // 
            // lblDefMod
            // 
            this.lblDefMod.AutoSize = true;
            this.lblDefMod.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDefMod.Location = new System.Drawing.Point(149, 612);
            this.lblDefMod.Name = "lblDefMod";
            this.lblDefMod.Size = new System.Drawing.Size(83, 16);
            this.lblDefMod.TabIndex = 17;
            this.lblDefMod.Text = "DEF Modifier";
            // 
            // lblActMod
            // 
            this.lblActMod.AutoSize = true;
            this.lblActMod.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActMod.Location = new System.Drawing.Point(149, 642);
            this.lblActMod.Name = "lblActMod";
            this.lblActMod.Size = new System.Drawing.Size(82, 16);
            this.lblActMod.TabIndex = 16;
            this.lblActMod.Text = "ACT Modifier";
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCost.Location = new System.Drawing.Point(149, 72);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(35, 16);
            this.lblCost.TabIndex = 15;
            this.lblCost.Text = "Cost";
            // 
            // lblTE
            // 
            this.lblTE.AutoSize = true;
            this.lblTE.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTE.Location = new System.Drawing.Point(149, 102);
            this.lblTE.Name = "lblTE";
            this.lblTE.Size = new System.Drawing.Size(80, 16);
            this.lblTE.TabIndex = 14;
            this.lblTE.Text = "Target Effect";
            // 
            // lblTT
            // 
            this.lblTT.AutoSize = true;
            this.lblTT.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTT.Location = new System.Drawing.Point(149, 132);
            this.lblTT.Name = "lblTT";
            this.lblTT.Size = new System.Drawing.Size(74, 16);
            this.lblTT.TabIndex = 13;
            this.lblTT.Text = "Target Type";
            // 
            // lblStrength
            // 
            this.lblStrength.AutoSize = true;
            this.lblStrength.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStrength.Location = new System.Drawing.Point(149, 162);
            this.lblStrength.Name = "lblStrength";
            this.lblStrength.Size = new System.Drawing.Size(57, 16);
            this.lblStrength.TabIndex = 12;
            this.lblStrength.Text = "Strength";
            // 
            // lblPower
            // 
            this.lblPower.AutoSize = true;
            this.lblPower.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPower.Location = new System.Drawing.Point(149, 192);
            this.lblPower.Name = "lblPower";
            this.lblPower.Size = new System.Drawing.Size(44, 16);
            this.lblPower.TabIndex = 11;
            this.lblPower.Text = "Power";
            // 
            // lblRange
            // 
            this.lblRange.AutoSize = true;
            this.lblRange.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRange.Location = new System.Drawing.Point(149, 222);
            this.lblRange.Name = "lblRange";
            this.lblRange.Size = new System.Drawing.Size(45, 16);
            this.lblRange.TabIndex = 10;
            this.lblRange.Text = "Range";
            // 
            // lblCharge1
            // 
            this.lblCharge1.AutoSize = true;
            this.lblCharge1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCharge1.Location = new System.Drawing.Point(149, 252);
            this.lblCharge1.Name = "lblCharge1";
            this.lblCharge1.Size = new System.Drawing.Size(78, 16);
            this.lblCharge1.TabIndex = 9;
            this.lblCharge1.Text = "Cast Time 1";
            // 
            // lblCharge5
            // 
            this.lblCharge5.AutoSize = true;
            this.lblCharge5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCharge5.Location = new System.Drawing.Point(149, 282);
            this.lblCharge5.Name = "lblCharge5";
            this.lblCharge5.Size = new System.Drawing.Size(78, 16);
            this.lblCharge5.TabIndex = 8;
            this.lblCharge5.Text = "Cast Time 5";
            // 
            // lblRecovery
            // 
            this.lblRecovery.AutoSize = true;
            this.lblRecovery.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecovery.Location = new System.Drawing.Point(149, 312);
            this.lblRecovery.Name = "lblRecovery";
            this.lblRecovery.Size = new System.Drawing.Size(93, 16);
            this.lblRecovery.TabIndex = 7;
            this.lblRecovery.Text = "Recovery Time";
            // 
            // lblAnimation
            // 
            this.lblAnimation.AutoSize = true;
            this.lblAnimation.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnimation.Location = new System.Drawing.Point(149, 342);
            this.lblAnimation.Name = "lblAnimation";
            this.lblAnimation.Size = new System.Drawing.Size(66, 16);
            this.lblAnimation.TabIndex = 6;
            this.lblAnimation.Text = "Animation";
            // 
            // lblIPD
            // 
            this.lblIPD.AutoSize = true;
            this.lblIPD.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIPD.Location = new System.Drawing.Point(149, 372);
            this.lblIPD.Name = "lblIPD";
            this.lblIPD.Size = new System.Drawing.Size(72, 16);
            this.lblIPD.TabIndex = 5;
            this.lblIPD.Text = "IP Damage";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(149, 42);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(42, 16);
            this.lblName.TabIndex = 4;
            this.lblName.Text = "Name";
            // 
            // lblIcon
            // 
            this.lblIcon.AutoSize = true;
            this.lblIcon.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIcon.Location = new System.Drawing.Point(149, 12);
            this.lblIcon.Name = "lblIcon";
            this.lblIcon.Size = new System.Drawing.Size(32, 16);
            this.lblIcon.TabIndex = 3;
            this.lblIcon.Text = "Icon";
            // 
            // txbSpecial
            // 
            this.txbSpecial.Location = new System.Drawing.Point(273, 696);
            this.txbSpecial.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbSpecial.Name = "txbSpecial";
            this.txbSpecial.Size = new System.Drawing.Size(116, 22);
            this.txbSpecial.TabIndex = 1;
            // 
            // MS_cmbo
            // 
            this.MS_cmbo.FormattingEnabled = true;
            this.MS_cmbo.Location = new System.Drawing.Point(3, 4);
            this.MS_cmbo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MS_cmbo.Name = "MS_cmbo";
            this.MS_cmbo.Size = new System.Drawing.Size(140, 24);
            this.MS_cmbo.TabIndex = 0;
            this.MS_cmbo.SelectedIndexChanged += new System.EventHandler(this.MS_cmbo_SelectedIndexChanged);
            // 
            // Skills
            // 
            this.Skills.Location = new System.Drawing.Point(4, 25);
            this.Skills.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Skills.Name = "Skills";
            this.Skills.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Skills.Size = new System.Drawing.Size(2156, 1345);
            this.Skills.TabIndex = 1;
            this.Skills.Text = "Skills";
            this.Skills.UseVisualStyleBackColor = true;
            // 
            // Levels
            // 
            this.Levels.Location = new System.Drawing.Point(4, 25);
            this.Levels.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Levels.Name = "Levels";
            this.Levels.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Levels.Size = new System.Drawing.Size(2156, 1345);
            this.Levels.TabIndex = 2;
            this.Levels.Text = "Levels";
            this.Levels.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2193, 1404);
            this.Controls.Add(this.tabCtrl);
            this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabCtrl.ResumeLayout(false);
            this.Moves.ResumeLayout(false);
            this.Moves.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabCtrl;
        private System.Windows.Forms.TabPage Moves;
        private System.Windows.Forms.TabPage Skills;
        private System.Windows.Forms.TabPage Levels;
        private System.Windows.Forms.ComboBox MS_cmbo;
        private System.Windows.Forms.Label lblIPC;
        private System.Windows.Forms.Label lblKnockback;
        private System.Windows.Forms.Label lblElement;
        private System.Windows.Forms.Label lblElementMod;
        private System.Windows.Forms.Label lblAilment;
        private System.Windows.Forms.Label lblAilmentChance;
        private System.Windows.Forms.Label lblStrMod;
        private System.Windows.Forms.Label lblDefMod;
        private System.Windows.Forms.Label lblActMod;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.Label lblTE;
        private System.Windows.Forms.Label lblTT;
        private System.Windows.Forms.Label lblStrength;
        private System.Windows.Forms.Label lblPower;
        private System.Windows.Forms.Label lblRange;
        private System.Windows.Forms.Label lblCharge1;
        private System.Windows.Forms.Label lblCharge5;
        private System.Windows.Forms.Label lblRecovery;
        private System.Windows.Forms.Label lblAnimation;
        private System.Windows.Forms.Label lblIPD;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblIcon;
        private System.Windows.Forms.TextBox txbSpecial;
        private System.Windows.Forms.Label lblMovMod;
        private System.Windows.Forms.Label lblSpecial;
        private System.Windows.Forms.Label lblCost1;
        private System.Windows.Forms.Label lblCost2;
        private System.Windows.Forms.Label lblCost3;
        private System.Windows.Forms.Label lblCost4;
        private System.Windows.Forms.Label lblCost5;
        private System.Windows.Forms.Label lblMultiplier;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.TextBox txbMultiplier;
        private System.Windows.Forms.TextBox txbDescription;
        private System.Windows.Forms.TextBox txbCost1;
        private System.Windows.Forms.TextBox txbCost2;
        private System.Windows.Forms.TextBox txbMovMod;
        private System.Windows.Forms.TextBox txbActMod;
        private System.Windows.Forms.TextBox txbDefMod;
        private System.Windows.Forms.TextBox txbStrMod;
        private System.Windows.Forms.TextBox txbAilmentChance;
        private System.Windows.Forms.TextBox txbAilments;
        private System.Windows.Forms.TextBox txbCost3;
        private System.Windows.Forms.TextBox txbCost4;
        private System.Windows.Forms.TextBox txbElementMod;
        private System.Windows.Forms.TextBox txbElement;
        private System.Windows.Forms.TextBox txbKnockback;
        private System.Windows.Forms.TextBox txbIPC;
        private System.Windows.Forms.TextBox txbIPD;
        private System.Windows.Forms.TextBox txbAnimation;
        private System.Windows.Forms.TextBox txbRecovery;
        private System.Windows.Forms.TextBox txbCastTime5;
        private System.Windows.Forms.TextBox txbCastTime1;
        private System.Windows.Forms.TextBox txbRange;
        private System.Windows.Forms.TextBox txbPower;
        private System.Windows.Forms.TextBox txbStrength;
        private System.Windows.Forms.TextBox txbTT;
        private System.Windows.Forms.TextBox txbTE;
        private System.Windows.Forms.TextBox txbCost;
        private System.Windows.Forms.TextBox txbName;
        private System.Windows.Forms.TextBox txbIcon;
        private System.Windows.Forms.TextBox txbCost5;
    }
}

